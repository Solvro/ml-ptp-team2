import numpy as np 
import pandas as pd 
import pytorch_lightning as pl 
import os 
import matplotlib.pyplot as plt
from pathlib import Path
import nibabel as nib
import torch.nn.functional as F
import torch.nn as nn
from typing import Literal
import torch
from torch.utils.data import TensorDataset, DataLoader
from torchvision import transforms




# Definicja klasy UNet3D
class UNet3D(pl.LightningModule):
    def __init__(self):
        super(UNet3D, self).__init__()

        # Encoder (zmniejszenie wymiarowości)
        self.encoder = nn.Sequential(
            nn.Conv3d(1, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv3d(64, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool3d(kernel_size=2, stride=2)
        )

        # Bottleneck (bez zmiany wymiarowości)
        self.bottleneck = nn.Sequential(
            nn.Conv3d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv3d(128, 128, kernel_size=3, padding=1),
            nn.ReLU(inplace=True)
        )

        # Decoder (zwiększenie wymiarowości)
        self.decoder = nn.Sequential(
            nn.Conv3d(128, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv3d(64, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.ConvTranspose3d(64, 1, kernel_size=2, stride=2)
        )

    def forward(self, x):
        # Przejście przez encoder
        enc1 = self.encoder(x)

        # Przejście przez bottleneck
        bottleneck = self.bottleneck(enc1)

        # Przejście przez decoder
        output = self.decoder(bottleneck)

        return output

    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(), lr=1e-3)


# Funkcja training_data_generator zostaje wcześniej zdefiniowana
def training_data_generator(seismic: np.ndarray, axis: Literal['i_line', 'x_line', None]=None, percentile: int=25):
    """Function to delete part of original seismic volume and extract target region

    Parameters:
        seismic: np.ndarray 3D matrix with original survey
        axis: one of 'i_line','x_line' or None. Axis along which part of survey will be deleted.
              If None (default), random will be chosen
        percentile: int, size of deleted part relative to axis. Any integer between 1 and 99 (default 20)

    Returns:
        seismic: np.ndarray, original survey 3D matrix with deleted region
        target: np.ndarray, 3D deleted region
        target_mask: np.ndarray, position of target 3D matrix in seismic 3D matrix. 
                     This mask is used to reconstruct original survey -> seismic[target_mask]=target.reshape(-1)
    """

    # check parameters
    assert isinstance(seismic, np.ndarray) and len(seismic.shape)==3, 'seismic must be 3D numpy.ndarray'
    assert axis in ['i_line', 'x_line', None], 'axis must be one of: i_line, x_line or None'
    assert type(percentile) is int and 0<percentile<100, 'percentile must be an integer between 0 and 100'

    k = seismic

    # rescale volume
    minval = np.percentile(seismic, 2)
    maxval = np.percentile(seismic, 98)
    seismic = np.clip(seismic, minval, maxval)
    seismic = ((seismic - minval) / (maxval - minval)) * 255

    # if axis is None get random choice
    if axis is None:
        axis = np.random.choice(['i_line', 'x_line'], 1)[0]

    # crop subset
    if axis == 'i_line':
        sample_size = np.round(seismic.shape[0]*(percentile/100)).astype('int')
        sample_start = np.random.choice(range(seismic.shape[0]-sample_size), 1)[0]
        sample_end = sample_start+sample_size

        target_mask = np.zeros(seismic.shape).astype('bool')
        target_mask[sample_start:sample_end, :, :] = True

        target = seismic[sample_start:sample_end, :, :].copy()
        seismic[target_mask] = np.nan

    else:
        sample_size = np.round(seismic.shape[1]*(percentile/100)).astype('int')
        sample_start = np.random.choice(range(seismic.shape[1]-sample_size), 1)[0]
        sample_end = sample_start+sample_size

        target_mask = np.zeros(seismic.shape).astype('bool')
        target_mask[:, sample_start:sample_end, :] = True

        target = seismic[:, sample_start:sample_end, :].copy()
        seismic[target_mask] = np.nan

    return seismic, k, target_mask

# Funkcja przygotowująca dane treningowe z plików NIfTI
def prepare_training_data(file_paths):
    seismic_data = []
    target_data = []
    for file_path in file_paths:
        # Wczytanie danych z pliku NIfTI
        nifti_data = nib.load(file_path)
        data_array = nifti_data.get_fdata()

        # Wybór odpowiednich wymiarów danych
        data_array = data_array[0:100, 0:100, 359:]

        # Wywołanie funkcji training_data_generator na wczytanych danych
        seismic, target, target_mask = training_data_generator(data_array, axis='i_line', percentile=25)  # Ustawiamy percentile na 25


        # Definicja transformacji normalizującej
        normalize = transforms.Normalize(mean=[0.00570423334215868], std=[99.74400990247878])  # Ustawienie średniej i odchylenia standardowego

        # Normalizacja danych
        seismic_tensor = torch.tensor(seismic, dtype=torch.float32)
        target_tensor = torch.tensor(target, dtype=torch.float32)

        seismic = normalize(seismic_tensor)
        target = normalize(target_tensor)

        # Dodanie danych do listy
        seismic_data.append(seismic)
        target_data.append(target)

    # Konwersja list na tensory PyTorch
    seismic_data = torch.stack(seismic_data)
    target_data = torch.stack(target_data)

    return seismic_data, target_data

# Ścieżka do katalogu zawierającego dane treningowe w formacie NIfTI
data_dir = Path("C:\\Users\\mikol\\OneDrive\\Pulpit\\ptp_dataset")
train_generated_dir = data_dir / "generated_part1_nii_gz" 

# Wczytanie ścieżek plików NIfTI z katalogu
file_paths = list(train_generated_dir.glob("*.nii.gz"))

# Przygotowanie danych treningowych
seismic, target = prepare_training_data(file_paths)

# Utworzenie DataLoadera
dataset = TensorDataset(seismic, target)
dataloader = DataLoader(dataset, batch_size=1, shuffle=True)

# Inicjalizacja modelu
model = UNet3D()

# Definicja funkcji straty
criterion = nn.MSELoss()

# Definicja optymalizatora
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

# Trenowanie modelu
epochs = 10
for epoch in range(epochs):
    for batch in dataloader:
        input_data, target_data = batch
        output = model(input_data)
        loss = criterion(output, target_data)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    print(f'Epoch [{epoch+1}/{epochs}], Loss: {loss.item()}')