import numpy as np 
import pandas as pd 
import pytorch_lightning as pl 
import os 
import matplotlib.pyplot as plt
from pathlib import Path
import nibabel as nib
import torch.nn.functional as F
import torch.nn as nn
from typing import Literal
import torch
from torch.utils.data import TensorDataset, DataLoader
from torchvision import transforms


data_dir = Path("C:\\Users\\mikol\\OneDrive\\Pulpit\\ptp_dataset")
train_generated_dir = data_dir / "generated_part1_nii_gz" 
train_real_dir = data_dir / 'real_nii_gz' 

train_generated_data = [nib.load(path) for path in list(train_generated_dir.glob("*.nii.gz"))]

def training_data_generator(seismic: np.ndarray, axis: Literal['i_line', 'x_line', None]=None, percentile: int=25):
    """Function to delete part of original seismic volume and extract target region

    Parameters:
        seismic: np.ndarray 3D matrix with original survey
        axis: one of 'i_line','x_line' or None. Axis along which part of survey will be deleted.
              If None (default), random will be chosen
        percentile: int, size of deleted part relative to axis. Any integer between 1 and 99 (default 20)

    Returns:
        seismic: np.ndarray, original survey 3D matrix with deleted region
        target: np.ndarray, 3D deleted region
        target_mask: np.ndarray, position of target 3D matrix in seismic 3D matrix. 
                     This mask is used to reconstruct original survey -> seismic[target_mask]=target.reshape(-1)
    """

    # check parameters
    assert isinstance(seismic, np.ndarray) and len(seismic.shape)==3, 'seismic must be 3D numpy.ndarray'
    assert axis in ['i_line', 'x_line', None], 'axis must be one of: i_line, x_line or None'
    assert type(percentile) is int and 0<percentile<100, 'percentile must be an integer between 0 and 100'

    # rescale volume
    minval = np.percentile(seismic, 2)
    maxval = np.percentile(seismic, 98)
    seismic = np.clip(seismic, minval, maxval)
    seismic = ((seismic - minval) / (maxval - minval)) * 255

    # if axis is None get random choice
    if axis is None:
        axis = np.random.choice(['i_line', 'x_line'], 1)[0]

    # crop subset
    if axis == 'i_line':
        sample_size = np.round(seismic.shape[0]*(percentile/100)).astype('int')
        sample_start = np.random.choice(range(seismic.shape[0]-sample_size), 1)[0]
        sample_end = sample_start+sample_size

        target_mask = np.zeros(seismic.shape).astype('bool')
        target_mask[sample_start:sample_end, :, :] = True

        target = seismic[sample_start:sample_end, :, :].copy()
        seismic[target_mask] = np.nan

    else:
        sample_size = np.round(seismic.shape[1]*(percentile/100)).astype('int')
        sample_start = np.random.choice(range(seismic.shape[1]-sample_size), 1)[0]
        sample_end = sample_start+sample_size

        target_mask = np.zeros(seismic.shape).astype('bool')
        target_mask[:, sample_start:sample_end, :] = True

        target = seismic[:, sample_start:sample_end, :].copy()
        seismic[target_mask] = np.nan

    return seismic, target, target_mask

s, t, tm = training_data_generator(train_generated_data[0].get_fdata())
print(s.shape, t.shape, tm.shape)