"""Example script"""
